import moment from 'moment';

var today = new Date();
var horas = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();

const employeesData = [
  {
    id: 1,
    token: '[token]',
    data: '20/11/2022',
    horaEntr: '11:20:15',
    horaSaida: '13:30:37',
  },
  {
    id: 2,
    token: '[token]',
    data: '20/11/2022',
    horaEntr: '11:20:15',
    horaSaida: '13:30:13',
  },
  {
    id: 3,
    token: '[token]',
    data: '20/11/2022',
    horaEntr: '11:20:15',
    horaSaida: '13:30:15',
  },
  {
    id: 4,
    token: '[token]',
    data: '20/11/2022',
    horaEntr: '11:20:15',
    horaSaida: '13:30:15',
  },
  {
    id: 5,
    token: '[token]',
    data: '20/11/2022',
    horaEntr: '11:20:15',
    horaSaida: '13:30:15',
  },
  {
    id: 6,
    token: '[token]',
    data: '20/11/2022',
    horaEntr: '11:20:15',
    horaSaida: '13:30:15',
  },
  {
    id: 7,
    token: '[token]',
    data: '20/11/2022',
    horaEntr: '11:20:15',
    horaSaida: '13:30:15',
  },
  {
    id: 8,
    token: '[token]',
    data: '20/11/2022',
    horaEntr: '11:20:15',
    horaSaida: '13:30:15',
  },
  {
    id: 9,
    token: '[token]',
    data: '20/11/2022',
    horaEntr: '11:20:15',
    horaSaida: '13:30:15',
  },
  {
    id: 10,
    token: '[token]',
    data: '20/11/2022',
    horaEntr: '11:20:15',
    horaSaida: '13:30:15',
  },
];

export { employeesData };
